# Map images

Required aspect ratios:

- World: doesn't matter too much (it will be distorted a bit, but should not matter too much)