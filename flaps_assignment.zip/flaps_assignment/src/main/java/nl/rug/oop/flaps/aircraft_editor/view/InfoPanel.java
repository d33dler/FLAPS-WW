package nl.rug.oop.flaps.aircraft_editor.view;

import nl.rug.oop.flaps.aircraft_editor.model.EditorCore;

import javax.swing.*;

public class InfoPanel extends JPanel {
    EditorCore model;

    public InfoPanel(EditorCore model) {
        this.model = model;
    }
}
