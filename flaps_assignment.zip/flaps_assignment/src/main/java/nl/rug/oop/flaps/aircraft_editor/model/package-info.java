/**
 * This package contains the model for the editor. For editors in general, the
 * "model" usually holds all the state information about which things are
 * selected, and what the user is doing.
 */
package nl.rug.oop.flaps.aircraft_editor.model;