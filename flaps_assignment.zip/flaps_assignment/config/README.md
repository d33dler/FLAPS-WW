# Config

This directory can be used to specify specific parameters of the simulation.

# Map

In the map.yaml, the image that is to be used for the map is specified.
If you want, you should be able to alter to this to another type of image.
However, all the coordinate calculations use the Mercator projection, so it
only supports those types of images. Be sure to set the starting/ending longitude/latitude
of your map correctly. 