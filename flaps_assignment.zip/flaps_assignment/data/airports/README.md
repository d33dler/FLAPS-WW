# Airports

Here all the airports of the world are defined. 

Credit to Wikipedia for the majority of the airport descriptions.