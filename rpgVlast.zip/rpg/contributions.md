# Work Distribution

Radu Rebeja :
World generation
NPC generation
Combat System
Door, Room features
Item scattering
Randomizer
Materials
Builders


Eugen Falca:

Menu Tree System
TypeWriter Feature
Player System
Inventory System
Materials
