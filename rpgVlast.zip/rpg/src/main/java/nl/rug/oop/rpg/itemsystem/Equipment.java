package nl.rug.oop.rpg.itemsystem;

public class Equipment {
    //tbd dlc
}
