package nl.rug.oop.rpg.npcsystem;

import nl.rug.oop.rpg.worldsystem.Player;

public interface Attackable {
    void receiveattack(Player x);
}
