package nl.rug.oop.rpg.npcsystem;

import nl.rug.oop.rpg.worldsystem.Player;

public class Allies extends NPC {

    public Allies(EntityBuilder parameters) {
        super(parameters);
    }

    @Override
    public void interact(Player a) {

    }
}
