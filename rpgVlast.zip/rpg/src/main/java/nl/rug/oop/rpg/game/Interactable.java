package nl.rug.oop.rpg.game;

import nl.rug.oop.rpg.worldsystem.Player;

public interface Interactable {
    void interact(Player a);
}
