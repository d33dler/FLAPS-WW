package nl.rug.oop.rpg;

import nl.rug.oop.rpg.menu.MainMenu;

public class Main {

    /**
     * comentariu
     * @param args
     */

    public static void main(String[] args) {
    new MainMenu().initMenu();
    }
}
