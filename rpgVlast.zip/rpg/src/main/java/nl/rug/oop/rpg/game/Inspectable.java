package nl.rug.oop.rpg.game;

import nl.rug.oop.rpg.worldsystem.Player;

public interface Inspectable {
   void inspect(Player x);
}
